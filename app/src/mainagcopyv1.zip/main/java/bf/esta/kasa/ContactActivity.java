package bf.esta.kasa;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
//Step 12: Working with the NewCourseActivity.java file
public class ContactActivity extends AppCompatActivity {
    // creating a variables for our button and edittext.
    private EditText courseNameEdt,coursePrenameEdt, courseTelEdt,courseDescEdt;
    private Button courseBtn;

    // creating a constant string variable for our
    // course name, description and duration.
    public static final String EXTRA_ID = "com.gtappdevelopers.gfgroomdatabase.EXTRA_ID";
    public static final String EXTRA_COURSE_NAME = "com.gtappdevelopers.gfgroomdatabase.EXTRA_COURSE_NAME";
    public static final String EXTRA_COURSE_PRENAME = "com.gtappdevelopers.gfgroomdatabase.EXTRA_COURSE_PRENAME";
    public static final String EXTRA_TEL = "com.gtappdevelopers.gfgroomdatabase.EXTRA_COURSE_TEL";
    public static final String EXTRA_DESCRIPTION = "com.gtappdevelopers.gfgroomdatabase.EXTRA_COURSE_DESCRIPTION";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact);
        // initializing our variables for each view.
        courseNameEdt = findViewById(R.id.idEdtCourseName);
        coursePrenameEdt = findViewById(R.id.idEdtCoursePrename);
        courseDescEdt = findViewById(R.id.idEdtCourseDescription);
        courseTelEdt = findViewById(R.id.idEdtCourseTel);
        courseBtn = findViewById(R.id.idBtnSaveCourse);

        // below line is to get intent as we
        // are getting data via an intent.
        Intent intent = getIntent();
        if (intent.hasExtra(EXTRA_ID)) {
            int id = intent.getIntExtra(EXTRA_ID, -1);
            System.out.println("2:"+id);
            int tel = intent.getIntExtra(EXTRA_TEL, 0000);
            System.out.println("3:"+tel);
            // if we get id for our data then we are
            // setting values to our edit text fields.
            courseNameEdt.setText(intent.getStringExtra(EXTRA_COURSE_NAME));
            coursePrenameEdt.setText(intent.getStringExtra(EXTRA_COURSE_PRENAME));
            courseDescEdt.setText(intent.getStringExtra(EXTRA_DESCRIPTION));
            //courseTelEdt.setText(Integer.parseInt(intent.getStringExtra(EXTRA_TEL)));
            courseTelEdt.setText(Integer.toString(tel));
        }
        // adding on click listener for our save button.
        courseBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // getting text value from edittext and validating if
                // the text fields are empty or not.
                String courseName = courseNameEdt.getText().toString();
                String coursePrename = coursePrenameEdt.getText().toString();
                String courseDesc = courseDescEdt.getText().toString();
                String courseTel = courseTelEdt.getText().toString();
                if (courseName.isEmpty() || coursePrename.isEmpty() || courseDesc.isEmpty() || courseTel.isEmpty()) {
                    Toast.makeText(ContactActivity.this, "Veuillez entrer les détails contact.", Toast.LENGTH_SHORT).show();
                    return;
                }
                // calling a method to save our course.
                saveCourse(courseName,coursePrename, courseDesc, courseTel);
            }
        });
    }
    private void saveCourse(String courseName,String coursePrename, String courseDescription, String courseTel) {
        // inside this method we are passing
        // all the data via an intent.
        Intent data = new Intent();

        // in below line we are passing all our course detail.
        data.putExtra(EXTRA_COURSE_NAME, courseName);
        data.putExtra(EXTRA_COURSE_PRENAME, coursePrename);
        data.putExtra(EXTRA_DESCRIPTION, courseDescription);
        data.putExtra(EXTRA_TEL, courseTel);
        int id = getIntent().getIntExtra(EXTRA_ID, -1);
        if (id != -1) {
            // in below line we are passing our id.
            data.putExtra(EXTRA_ID, id);
        }

        // at last we are setting result as data.
        setResult(RESULT_OK, data);

        // displaying a toast message after adding the data
        Toast.makeText(this, "Contact a été enregistré dans la Room Database. ", Toast.LENGTH_SHORT).show();
    }
}